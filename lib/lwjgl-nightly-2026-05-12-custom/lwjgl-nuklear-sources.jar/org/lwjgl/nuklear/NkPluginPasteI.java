/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.nuklear;

import org.lwjgl.system.*;

import java.lang.invoke.*;

import static org.lwjgl.system.APIUtil.*;
import static org.lwjgl.system.MemoryUtil.*;
import static org.lwjgl.system.libffi.LibFFI.*;

/** Callback function: {@link #invoke nk_plugin_paste} */
@FunctionalInterface
@NativeType("nk_plugin_paste")
public interface NkPluginPasteI extends CallbackI {

    Callback.Descriptor DESCRIPTOR = new Callback.Descriptor(
        NkPluginPasteI.class,
        MethodHandles.lookup(),
        apiCreateCIF(
            ffi_type_void,
            ffi_type_pointer, ffi_type_pointer
        )
    );

    @Override
    default Callback.Descriptor getDescriptor() { return DESCRIPTOR; }

    @Override
    default void callback(long ret, long args) {
        invoke(
            memGetAddress(memGetAddress(args)),
            memGetAddress(memGetAddress(args + POINTER_SIZE))
        );
    }

    /** {@code void (* nk_plugin_paste) (nk_handle handle, struct nk_text_edit * edit)} */
    void invoke(@NativeType("nk_handle") long handle, @NativeType("struct nk_text_edit *") long edit);

}